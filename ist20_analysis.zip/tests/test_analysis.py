import io
import json
import random
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ist20_analysis import ANALYSES, indicators as ind
from ist20_analysis.analyses import _cap_weights
from ist20_analysis.cli import main
from ist20_analysis.models import TONES, Row
from ist20_analysis.provider import Coin, CoinGeckoProvider, ProviderError, _resample

IDS = ["bitcoin", "ethereum", "solana", "bittensor", "ripple", "dogecoin", "chainlink", "near"]


def walk(seed, n=365, drift=0.001, base=None):
    rng = random.Random(seed)
    base = base or [rng.gauss(drift, 0.02) for _ in range(n)]
    p, out = 100.0, []
    for r in base:
        p *= 1 + r
        out.append(p)
    return out


class Fake:
    def __init__(self):
        rng = random.Random(1)
        self.btc_r = [rng.gauss(0.001, 0.02) for _ in range(365)]
        self.data = {}
        for i, cid in enumerate(IDS):
            rho = 1.0 if cid == "bitcoin" else (0.9 - 0.12 * i)
            rr = random.Random(10 + i)
            r = [rho * b + (1 - abs(rho)) * rr.gauss(0, 0.03) for b in self.btc_r]
            self.data[cid] = walk(0, base=r)

    def universe(self):
        return [Coin(c, c[:4].upper(), 1e9) for c in IDS]

    def closes(self, cid, tf):
        d = self.data[cid]
        return {"1d": d, "1w": _resample(d, 7), "1M": _resample(d, 30),
                "4h": d[-180:], "15m": d[-96:]}[tf]


class Indicators(unittest.TestCase):
    def test_rsi_extremes(self):
        self.assertEqual(ind.rsi(list(range(1, 60))), 100.0)
        self.assertLess(ind.rsi(list(range(60, 1, -1))), 1)

    def test_ema_constant(self):
        self.assertAlmostEqual(ind.last(ind.ema([5.0] * 50, 20)), 5.0)

    def test_pearson(self):
        a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
        self.assertAlmostEqual(ind.pearson(a, a), 1.0)
        self.assertAlmostEqual(ind.pearson(a, [-x for x in a]), -1.0)

    def test_resample_aligned_to_end(self):
        self.assertEqual(_resample(list(range(10)), 3), [3, 6, 9])


class Analyses(unittest.TestCase):
    def test_all_return_valid_rows(self):
        p = Fake()
        for a in ANALYSES:
            res = a.fn(p, "bitcoin", None)
            self.assertTrue(res.rows, a.id)
            for r in res.rows:
                self.assertIn(r.tone, TONES)
                self.assertTrue(0 <= r.pct <= 100)
            self.assertTrue(a.asks)

    def test_divergence_sorted(self):
        res = [a for a in ANALYSES if a.id == "divergence"][0].fn(Fake(), None, None)
        v = [float(r.val.split()[3].replace(",", ".")) for r in res.rows]
        self.assertEqual(v, sorted(v))

    def test_weights(self):
        res = [a for a in ANALYSES if a.id == "diversify"][0].fn(Fake(), None, None)
        w = [float(r.val.split()[2].replace(",", ".")) for r in res.rows]
        self.assertAlmostEqual(sum(w), 100, delta=3)  # redondeo a enteros
        self.assertLessEqual(max(r.pct for r in res.rows), 35.001)
        cap = _cap_weights({"a": 10, "b": 1, "c": 1, "d": 1})
        self.assertAlmostEqual(sum(cap.values()), 1.0)
        self.assertLessEqual(max(cap.values()), 0.35 + 1e-9)

    def test_row_rejects_bad_tone(self):
        with self.assertRaises(ValueError):
            Row("x", "y", 1, "z", "purple")

    def test_cli(self):
        buf = io.StringIO()
        self.assertEqual(main(["run", "compare"], provider=Fake(), out=buf), 0)
        self.assertIn("BTC", buf.getvalue())
        buf = io.StringIO()
        main(["list"], out=buf)
        self.assertEqual(len(buf.getvalue().splitlines()), len(ANALYSES))


class Canned(CoinGeckoProvider):
    calls = 0

    def _http_get(self, url):
        Canned.calls += 1
        if "/coins/markets" in url and "ids=bittensor" in url:
            return json.dumps([{"id": "bittensor", "symbol": "tao", "total_volume": 2},
                               {"id": "tether", "symbol": "usdt", "total_volume": 1}])
        if "/coins/markets" in url:
            return json.dumps([
                {"id": "tether", "symbol": "usdt", "total_volume": 1},
                {"id": "bitcoin", "symbol": "btc", "total_volume": 5},
                {"id": "wrapped-bitcoin", "symbol": "wbtc", "total_volume": 1},
                {"id": "ethereum", "symbol": "eth", "total_volume": 4}])
        if "/ohlc" in url:
            return json.dumps([[0, 1, 2, 0.5, 1.5]] * 4)
        return json.dumps({"prices": [[i, 100 + i] for i in range(30)]})


class ProviderTests(unittest.TestCase):
    def setUp(self):
        from ist20_analysis import config
        config.MIN_REQUEST_INTERVAL_S = 0
        self.tmp = tempfile.mkdtemp()
        Canned.calls = 0

    def test_universe_filters_and_adds_tao(self):
        p = Canned(cache_dir=self.tmp)
        ids = [c.id for c in p.universe()]
        self.assertEqual(ids[:2], ["bitcoin", "ethereum"])
        self.assertIn("bittensor", ids)
        self.assertNotIn("tether", ids)
        self.assertNotIn("wrapped-bitcoin", ids)

    def test_cache_hit(self):
        p = Canned(cache_dir=self.tmp)
        p.closes("bitcoin", "1d")
        n = Canned.calls
        p.closes("bitcoin", "1d")
        self.assertEqual(Canned.calls, n)

    def test_rejects_bad_ids(self):
        p = Canned(cache_dir=self.tmp)
        for bad in ("../etc/passwd", "btc?x=1", "", "A B", None):
            with self.assertRaises(ProviderError):
                p.closes(bad, "1d")

    def test_timeframes(self):
        p = Canned(cache_dir=self.tmp)
        self.assertEqual(len(p.closes("bitcoin", "4h")), 4)
        self.assertEqual(len(p.closes("bitcoin", "1w")), 4)


if __name__ == "__main__":
    unittest.main()
