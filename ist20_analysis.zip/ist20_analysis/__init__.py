"""IST-20 · módulo de análisis rápido (solo biblioteca estándar de Python)."""
from .analyses import ANALYSES, by_id
from .models import Result, Row

__all__ = ["ANALYSES", "by_id", "Result", "Row"]
