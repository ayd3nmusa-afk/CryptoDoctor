from dataclasses import dataclass, field
from typing import List

TONES = ("up", "mid", "down")


@dataclass
class Row:
    label: str
    val: str
    pct: float  # 0-100, longitud de la barra
    tag: str
    tone: str  # up | mid | down

    def __post_init__(self):
        self.pct = max(0.0, min(100.0, float(self.pct)))
        if self.tone not in TONES:
            raise ValueError("tone inválido: %r" % self.tone)


@dataclass
class Result:
    id: str
    title: str
    how: str
    rows: List[Row] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
