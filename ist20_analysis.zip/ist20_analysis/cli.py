"""Interfaz de línea de comandos. Desde run.py:  from ist20_analysis.cli import main"""
import argparse
import sys

from .analyses import ANALYSES, by_id
from .provider import CoinGeckoProvider, ProviderError


def format_result(res, width=24):
    out = [res.title, res.how, ""]
    for r in res.rows:
        bar = "#" * int(r.pct / 100 * width)
        out.append("%-30s %-44s |%-*s| %s" % (r.label[:30], r.val[:44], width, bar, r.tag))
    for n in res.notes:
        out += ["", "* " + n]
    return "\n".join(out)


def main(argv=None, provider=None, out=None):
    out = out or sys.stdout
    ap = argparse.ArgumentParser(prog="ist20_analysis")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list", help="lista los análisis")
    run = sub.add_parser("run", help="ejecuta un análisis")
    run.add_argument("id", choices=[a.id for a in ANALYSES])
    run.add_argument("--coin", default="bitcoin", help="id de CoinGecko (solo informe y multi-timeframe)")
    args = ap.parse_args(argv)

    if args.cmd == "list":
        for a in ANALYSES:
            out.write("%-13s %s · %s\n" % (a.id, a.button, a.sub))
        return 0
    a = by_id(args.id)
    provider = provider or CoinGeckoProvider()
    try:
        res = a.fn(provider, args.coin, lambda i, n, m: sys.stderr.write("[%d/%d] %s\n" % (i + 1, n, m)))
    except ProviderError as e:
        sys.stderr.write("Error: %s\n" % e)
        return 1
    out.write(format_result(res) + "\n")
    return 0
