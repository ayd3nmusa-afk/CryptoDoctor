"""Acceso a datos. Los análisis solo conocen la interfaz (universe, closes);
CoinGecko es una implementación intercambiable."""
import hashlib
import json
import os
import re
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import namedtuple
from pathlib import Path

from . import config

Coin = namedtuple("Coin", "id symbol volume")
_ID_RE = re.compile(r"[a-z0-9][a-z0-9-]{0,63}")
TIMEFRAMES = ("15m", "4h", "1d", "1w", "1M")


class ProviderError(Exception):
    pass


def _resample(values, step):
    """Último valor de cada bloque de `step`, alineado desde el final."""
    if step <= 1:
        return list(values)
    start = len(values) % step
    return [values[i + step - 1] for i in range(start, len(values) - step + 1, step)]


class CoinGeckoProvider:
    def __init__(self, cache_dir=None, api_key=None):
        self._dir = Path(cache_dir or Path.home() / ".ist20_cache")
        self._dir.mkdir(parents=True, exist_ok=True)
        # La clave (opcional) se lee del entorno; nunca va en el código.
        self._key = api_key or os.environ.get("COINGECKO_DEMO_API_KEY")
        self._lock = threading.Lock()
        self._last_call = 0.0

    # ---- interfaz pública -------------------------------------------------
    def universe(self):
        rows = self._cached_json(
            "universe", "/coins/markets",
            {"vs_currency": "usd", "order": "market_cap_desc", "per_page": 80, "page": 1})
        coins = [self._coin(r) for r in rows if self._eligible(r)][:config.UNIVERSE_SIZE]
        have = {c.id for c in coins}
        missing = [i for i in config.EXTRA_COINS if i not in have]
        if missing:
            extra = self._cached_json(
                "universe", "/coins/markets",
                {"vs_currency": "usd", "ids": ",".join(missing)})
            coins += [self._coin(r) for r in extra if r.get("id") in missing]
        return coins

    def closes(self, coin_id, tf):
        self._check_id(coin_id)
        if tf == "15m":
            d = self._cached_json("15m", "/coins/%s/market_chart" % coin_id,
                                  {"vs_currency": "usd", "days": 1})
            return _resample([p[1] for p in d["prices"]], 3)  # 5 min -> 15 min
        if tf == "4h":
            d = self._cached_json("4h", "/coins/%s/ohlc" % coin_id,
                                  {"vs_currency": "usd", "days": 30})
            return [c[4] for c in d]
        daily = self._daily(coin_id)
        if tf == "1d":
            return daily
        if tf == "1w":
            return _resample(daily, 7)
        if tf == "1M":
            return _resample(daily, 30)
        raise ProviderError("marco temporal desconocido: %r" % tf)

    # ---- internos ---------------------------------------------------------
    def _daily(self, coin_id):
        d = self._cached_json("1d", "/coins/%s/market_chart" % coin_id,
                              {"vs_currency": "usd", "days": 365, "interval": "daily"})
        return [p[1] for p in d["prices"]]

    @staticmethod
    def _eligible(r):
        sym = (r.get("symbol") or "").upper()
        cid = r.get("id") or ""
        return not (cid in config.STABLECOIN_IDS or sym in config.STABLECOIN_SYMBOLS
                    or cid in config.WRAPPED_IDS)

    @staticmethod
    def _coin(r):
        return Coin(r["id"], (r.get("symbol") or "").upper(), r.get("total_volume") or 0)

    @staticmethod
    def _check_id(coin_id):
        if not isinstance(coin_id, str) or not _ID_RE.fullmatch(coin_id):
            raise ProviderError("id de moneda no válido: %r" % (coin_id,))

    def _cached_json(self, ttl_key, path, params):
        query = urllib.parse.urlencode(sorted(params.items()))
        name = hashlib.sha256((path + "?" + query).encode()).hexdigest()[:32] + ".json"
        f = self._dir / name
        ttl = config.CACHE_TTL_S[ttl_key]
        try:
            if time.time() - f.stat().st_mtime < ttl:
                return json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        data = self._get_json(path, query)
        fd, tmp = tempfile.mkstemp(dir=str(self._dir))
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, f)  # escritura atómica
        return data

    def _get_json(self, path, query):
        url = config.BASE_URL + path + "?" + query
        for attempt in range(3):
            self._throttle()
            try:
                return json.loads(self._http_get(url))
            except urllib.error.HTTPError as e:
                if e.code == 429 and attempt < 2:
                    wait = int(e.headers.get("Retry-After", "30") or 30)
                    time.sleep(min(wait, 65))
                    continue
                raise ProviderError("CoinGecko respondió %s" % e.code)
            except (urllib.error.URLError, TimeoutError, ValueError) as e:
                raise ProviderError("error de red o formato: %s" % e)
        raise ProviderError("límite de peticiones de CoinGecko")

    def _http_get(self, url):
        headers = {"Accept": "application/json", "User-Agent": "IST-20"}
        if self._key:
            headers["x-cg-demo-key"] = self._key
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=config.REQUEST_TIMEOUT_S) as r:
            return r.read().decode("utf-8")

    def _throttle(self):
        with self._lock:
            wait = config.MIN_REQUEST_INTERVAL_S - (time.monotonic() - self._last_call)
            if wait > 0:
                time.sleep(wait)
            self._last_call = time.monotonic()
