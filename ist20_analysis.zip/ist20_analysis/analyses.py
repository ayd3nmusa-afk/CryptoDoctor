"""Los 10 análisis. Cada uno: fn(provider, coin, progress) -> Result.
Para añadir uno nuevo: escribe la función y regístrala en ANALYSES."""
from collections import namedtuple

from . import config
from .indicators import (bias, clamp, ema, last, macd, nearest_levels, pearson,
                         returns, rsi, slope, stdev)
from .models import Result, Row
from .provider import ProviderError

Analysis = namedtuple("Analysis", "id group button sub needs_coin fn asks")


# ---------- utilidades -------------------------------------------------------
def _n(x, d=2):
    return ("%.*f" % (d, x)).replace(".", ",")


def _price(x):
    return "$" + ("{:,.2f}".format(x)).replace(",", "X").replace(".", ",").replace("X", ".")


def _step(progress, i, n, msg):
    if progress:
        progress(i, n, msg)


def _universe_closes(p, progress, notes, tf="1d", min_len=60):
    """{coin: (Coin, closes)} del universo; salta monedas con error o poco historial."""
    coins = p.universe()
    out = {}
    for i, c in enumerate(coins):
        _step(progress, i, len(coins), "Descargando %s" % c.symbol)
        try:
            closes = p.closes(c.id, tf)
        except ProviderError as e:
            notes.append("%s omitida: %s" % (c.symbol, e))
            continue
        if len(closes) >= min_len:
            out[c.id] = (c, closes)
        else:
            notes.append("%s omitida: historial insuficiente" % c.symbol)
    if "bitcoin" not in out:
        raise ProviderError("sin datos de BTC: no se puede calcular")
    return out


def _rsi_row(label, c):
    r = rsi(c)
    if r is None:
        return Row(label, "sin datos", 0, "Sin datos", "mid")
    if r >= 70:
        tag, tone = "Sobrecompra", "down"
    elif r >= 55:
        tag, tone = "Alcista", "up"
    elif r >= 45:
        tag, tone = "Neutral", "mid"
    elif r >= 30:
        tag, tone = "Bajista", "down"
    else:
        tag, tone = "Sobreventa", "mid"
    return Row(label, "RSI %s" % _n(r, 0), r, tag, tone)


def _macd_row(label, c):
    h = macd(c)[2]
    cur, prev = h[-1], h[-2] if len(h) > 1 else None
    if cur is None or prev is None:
        return Row(label, "sin datos", 0, "Sin datos", "mid")
    if cur > 0 and prev <= 0:
        tag, tone = "Cruce alcista", "up"
    elif cur < 0 and prev >= 0:
        tag, tone = "Cruce bajista", "down"
    elif cur > 0:
        tag, tone = "Alcista", "up"
    else:
        tag, tone = "Bajista", "down"
    return Row(label, "Histograma %s%% del precio" % _n(cur / c[-1] * 100, 3),
               clamp(50 + cur / c[-1] * 2500, 5, 95), tag, tone)


def _ema_row(label, c):
    e20, e50 = last(ema(c, 20)), last(ema(c, 50))
    if e20 is None or e50 is None:
        return Row(label, "sin datos", 0, "Sin datos", "mid")
    above = (c[-1] > e20) + (c[-1] > e50)
    return {2: Row(label, "Precio sobre ambas", 75, "Alcista", "up"),
            1: Row(label, "Precio entre ambas", 50, "Neutral", "mid"),
            0: Row(label, "Precio bajo ambas", 25, "Bajista", "down")}[above]


def _rs_pct(rs):  # fuerza relativa (fracción) -> barra; ±10 % = extremos
    return clamp(50 + rs * 500, 5, 95)


def _rel7(c, btc):
    return (c[-1] / c[-8] - 1) - (btc[-1] / btc[-8] - 1)


# ---------- 1. BTC vs ETH ----------------------------------------------------
def compare_btc_eth(p, coin=None, progress=None):
    data = {}
    for i, (cid, sym) in enumerate((("bitcoin", "BTC"), ("ethereum", "ETH"))):
        _step(progress, i, 2, "Descargando %s" % sym)
        data[sym] = p.closes(cid, "1d")
    rows = []
    for fn, name in ((_rsi_row, "RSI 14 (1D)"), (_macd_row, "MACD vs señal"), (_ema_row, "EMA 20/50")):
        for sym, c in data.items():
            rows.append(fn("%s · %s" % (sym, name), c))
    m = min(len(data["BTC"]), len(data["ETH"]))
    ratio = [e / b for e, b in zip(data["ETH"][-m:], data["BTC"][-m:])]
    s = slope(ratio, 30)
    if s is not None:
        tag, tone = ("Fuerte", "up") if s > 0.0015 else ("Débil", "down") if s < -0.0015 else ("Lateral", "mid")
        rows.append(Row("Ratio ETH/BTC · 30 d", "Pendiente %s %%/día" % _n(s * 100, 3),
                        clamp(50 + s * 10000, 5, 95), tag, tone))
    return Result("compare", "BTC vs ETH · setup técnico",
                  "RSI 14, MACD, EMA 20/50 y tendencia del ratio ETH/BTC en velas diarias.", rows)


# ---------- 2. Divergencias --------------------------------------------------
def divergences(p, coin=None, progress=None):
    notes = []
    u = _universe_closes(p, progress, notes)
    btc_r = returns(u["bitcoin"][1])
    rows = []
    for cid, (c, closes) in u.items():
        if cid == "bitcoin":
            continue
        corr = pearson(returns(closes), btc_r, 30)
        if corr is None:
            continue
        tag, tone = (("Diverge", "up") if corr < 0.4 else ("Parcial", "mid") if corr < 0.65
                     else ("Sigue a BTC", "mid"))
        rows.append((corr, Row(c.symbol, "Corr. 30 d %s" % _n(corr), max(corr, 0) * 100, tag, tone)))
    rows.sort(key=lambda t: t[0])
    return Result("divergence", "Divergencias frente a BTC",
                  "Correlación de retornos diarios con BTC a 30 días, de menor a mayor.",
                  [r for _, r in rows], notes)


# ---------- 3. No correlacionadas -------------------------------------------
def uncorrelated(p, coin=None, progress=None):
    notes = []
    u = _universe_closes(p, progress, notes)
    btc_r = returns(u["bitcoin"][1])
    items = []
    for cid, (c, closes) in u.items():
        if cid == "bitcoin":
            continue
        corr = pearson(returns(closes), btc_r, 90)
        r = rsi(closes)
        if corr is None or r is None:
            continue
        ok_vol = c.volume >= config.MIN_VOLUME_USD
        if corr < 0.4 and 40 <= r <= 65 and ok_vol:
            tag, tone = "Candidata", "up"
        elif corr < 0.55:
            tag, tone = "En vigilancia", "mid"
        else:
            tag, tone = "Descartada", "down"
        items.append((corr, Row(c.symbol, "Corr. 90 d %s · RSI %s" % (_n(corr), _n(r, 0)),
                                max(corr, 0) * 100, tag, tone)))
    items.sort(key=lambda t: t[0])
    if config.MIN_VOLUME_USD:
        notes.append("Filtro de volumen activo: mínimo %s USD en 24 h." % _price(config.MIN_VOLUME_USD))
    return Result("uncorrelated", "Oportunidades no correlacionadas",
                  "Baja correlación a 90 días con BTC, confirmada con RSI entre 40 y 65.",
                  [r for _, r in items[:8]], notes)


# ---------- 4. Diversificación ----------------------------------------------
def _cap_weights(scores, cap=0.35):
    w = {k: v / sum(scores.values()) for k, v in scores.items()}
    for _ in range(10):
        over = {k for k, v in w.items() if v > cap + 1e-9}
        if not over:
            break
        excess = sum(w[k] - cap for k in over)
        for k in over:
            w[k] = cap
        free = [k for k in w if k not in over]
        tot = sum(w[k] for k in free)
        if not free or tot == 0:
            break
        for k in free:
            w[k] += excess * w[k] / tot
    return w


def diversification(p, coin=None, progress=None):
    notes = []
    u = _universe_closes(p, progress, notes)
    btc_r = returns(u["bitcoin"][1])
    scores = {}
    for cid, (c, closes) in u.items():
        corr = 0.0 if cid == "bitcoin" else (pearson(returns(closes), btc_r, 90) or 0.0)
        e50 = last(ema(closes, 50))
        trend = 1.0 if e50 and closes[-1] > e50 else 0.5
        scores[cid] = max(0.05, 1 - max(corr, 0)) * trend
    top = sorted(scores, key=scores.get, reverse=True)[:6]
    if "bitcoin" not in top:
        top = top[:5] + ["bitcoin"]
    w = _cap_weights({k: scores[k] for k in top})
    rows = [Row(u[k][0].symbol, "Peso sugerido %s %%" % _n(w[k] * 100, 0), w[k] * 100,
                "Base" if k in ("bitcoin", "ethereum") else "Satélite",
                "mid" if k in ("bitcoin", "ethereum") else "up")
            for k in sorted(top, key=w.get, reverse=True)]
    notes.append("Reparto orientativo (máx. 35 % por moneda) sobre las 6 mejor puntuadas; no es asesoramiento financiero.")
    return Result("diversify", "Diversificación según técnicos",
                  "Puntuación = (1 − correlación a 90 d con BTC) × tendencia sobre EMA 50.", rows, notes)


# ---------- 5. Rotación sectorial -------------------------------------------
def sector_rotation(p, coin=None, progress=None):
    notes = []
    u = _universe_closes(p, progress, notes)
    btc = u["bitcoin"][1]
    by = {}
    for cid, (c, closes) in u.items():
        if cid != "bitcoin":
            by.setdefault(config.SECTORS.get(cid, "Otros"), []).append(_rel7(closes, btc))
    rows = []
    for sec, vals in by.items():
        rs = sum(vals) / len(vals)
        tag, tone = ("Entra capital", "up") if rs > 0.03 else ("Sale capital", "down") if rs < -0.03 else ("Neutral", "mid")
        sign = "+" if rs >= 0 else "−"
        rows.append((rs, Row("%s (%d)" % (sec, len(vals)),
                             "Fuerza relativa %s%s %%" % (sign, _n(abs(rs) * 100, 1)), _rs_pct(rs), tag, tone)))
    rows.sort(key=lambda t: t[0], reverse=True)
    return Result("rotation", "Rotación sectorial",
                  "Rendimiento medio a 7 días de cada sector frente a BTC. Sectores editables en config.py.",
                  [r for _, r in rows], notes)


# ---------- 6. Sentimiento y régimen ----------------------------------------
def _breadth(u, n):
    ok = [c for _, (_, c) in u.items() if len(c) >= n and last(ema(c, n)) is not None]
    return (sum(1 for c in ok if c[-1] > last(ema(c, n))) / len(ok) * 100) if ok else None


def _breadth_row(label, v):
    tag, tone = ("Positiva", "up") if v >= 60 else ("Negativa", "down") if v <= 40 else ("Mixta", "mid")
    return Row(label, "%s %% del universo" % _n(v, 0), v, tag, tone)


def sentiment_regime(p, coin=None, progress=None):
    notes = []
    u = _universe_closes(p, progress, notes)
    btc = u["bitcoin"][1]
    b50, b20 = _breadth(u, 50), _breadth(u, 20)
    rows, scores = [], []
    for label, v in (("Amplitud · sobre EMA 50", b50), ("Amplitud · sobre EMA 20", b20)):
        if v is not None:
            rows.append(_breadth_row(label, v))
            scores.append(v)
    e200 = last(ema(btc, 200))
    if e200:
        s = slope(btc, 30) or 0
        sc, tag, tone = ((75, "Alcista", "up") if btc[-1] > e200 and s > 0 else
                         (25, "Bajista", "down") if btc[-1] < e200 and s < 0 else (50, "Neutral", "mid"))
        rows.append(Row("Tendencia de BTC", "Precio %s EMA 200" % ("sobre" if btc[-1] > e200 else "bajo"), sc, tag, tone))
        scores.append(sc)
    alts = [_rel7(c, btc) for cid, (_, c) in u.items() if cid != "bitcoin"]
    if alts:
        rs = sum(alts) / len(alts)
        tag, tone = ("Fuertes", "up") if rs > 0.02 else ("Débiles", "down") if rs < -0.02 else ("Neutral", "mid")
        rows.append(Row("Altcoins frente a BTC", "Media 7 d %s %%" % _n(rs * 100, 1), _rs_pct(rs), tag, tone))
        scores.append(_rs_pct(rs))
    comp = sum(scores) / len(scores)
    verdict, tone = ("Risk-on", "up") if comp >= 60 else ("Risk-off", "down") if comp <= 40 else ("Neutral", "mid")
    rows.append(Row("Veredicto del régimen", "Puntuación compuesta %s/100" % _n(comp, 0), comp, verdict, tone))
    notes.append("Acumulación/distribución y '¿buen momento?' no se calculan: harían falta datos de volumen y flujos, "
                 "y esto es una lectura técnica, no una recomendación.")
    return Result("sentiment", "Sentimiento y régimen de mercado",
                  "Veredicto compuesto de amplitud, tendencia de BTC y fuerza de altcoins.", rows, notes)


# ---------- 7. Amplitud y niveles -------------------------------------------
def _level_row(label, level, price, kind):
    if level is None:
        return Row(label, "sin nivel claro", 0, "Sin nivel", "mid")
    dist = abs(level / price - 1) * 100
    tone = "down" if kind == "s" else "up"
    return Row(label, "%s · a %s %% del precio" % (_price(level), _n(dist, 1)),
               clamp(100 - dist * 5, 5, 100),
               "Si se pierde, cambia la tendencia" if kind == "s" else "Si se rompe, confirma", tone)


def _weekly_structure(w):
    w = w[-8:]
    if len(w) < 8:
        return None
    a, b = w[:4], w[4:]
    if max(b) > max(a) and min(b) > min(a):
        return Row("Estructura semanal de BTC", "Máximos y mínimos crecientes", 70, "Alcista", "up")
    if max(b) < max(a) and min(b) < min(a):
        return Row("Estructura semanal de BTC", "Máximos y mínimos decrecientes", 30, "Bajista", "down")
    return Row("Estructura semanal de BTC", "Sin secuencia clara", 50, "Lateral", "mid")


def breadth_levels(p, coin=None, progress=None):
    notes = []
    u = _universe_closes(p, progress, notes)
    rows = []
    for label, n in (("Monedas sobre EMA 20", 20), ("Monedas sobre EMA 200", 200)):
        v = _breadth(u, n)
        if v is not None:
            rows.append(_breadth_row(label, v))
    btc = u["bitcoin"][1]
    ws = _weekly_structure(p.closes("bitcoin", "1w"))
    if ws:
        rows.append(ws)
    sup, res = nearest_levels(btc)
    rows.append(_level_row("Soporte principal de BTC", sup, btc[-1], "s"))
    rows.append(_level_row("Resistencia principal de BTC", res, btc[-1], "r"))
    notes.append("Niveles = pivotes de los últimos 180 días de cierres diarios.")
    return Result("levels", "Amplitud técnica y niveles clave",
                  "Cuántas monedas confirman la tendencia y qué niveles de BTC la cambiarían.", rows, notes)


# ---------- 8. Informe por activo -------------------------------------------
def asset_report(p, coin="bitcoin", progress=None):
    _step(progress, 0, 1, "Descargando %s" % coin)
    c = p.closes(coin, "1d")
    if len(c) < 60:
        raise ProviderError("historial insuficiente para %s" % coin)
    rows = []
    es = [last(ema(c, n)) for n in (20, 50, 200)]
    avail = [e for e in es if e is not None]
    above = sum(1 for e in avail if c[-1] > e)
    tag, tone, pct = (("Alcista", "up", 80) if above == len(avail) else
                      ("Bajista", "down", 20) if above == 0 else ("Mixta", "mid", 50))
    rows.append(Row("Tendencia", "Sobre %d de %d EMA (20/50/200)" % (above, len(avail)), pct, tag, tone))
    rows += [_rsi_row("Momentum · RSI 14", c), _macd_row("Momentum · MACD", c)]
    r = returns(c)
    s14, s60 = stdev(r[-14:]), stdev(r[-60:])
    if s14 and s60:
        k = s14 / s60
        tag, tone = ("Expansiva", "down") if k > 1.2 else ("Contenida", "up") if k < 0.8 else ("Normal", "mid")
        rows.append(Row("Volatilidad", "Desv. 14 d / 60 d = %s" % _n(k), clamp(k * 50, 5, 100), tag, tone))
    sup, res = nearest_levels(c)
    rows += [_level_row("Soporte de referencia", sup, c[-1], "s"),
             _level_row("Resistencia de referencia", res, c[-1], "r")]
    if sup and res:
        up_, dn = res / c[-1] - 1, 1 - sup / c[-1]
        rr = up_ / dn if dn > 0 else None
        if rr is not None:
            tag, tone = ("Favorable", "up") if rr >= 2 else ("Ajustada", "down") if rr < 1 else ("Moderada", "mid")
            rows.append(Row("Recorrido / riesgo", "Hasta resistencia %s %% · hasta soporte %s %%" %
                            (_n(up_ * 100, 1), _n(dn * 100, 1)), clamp(rr * 33, 5, 100),
                            "%s (%s:1)" % (tag, _n(rr, 1)), tone))
    return Result("asset", "Informe técnico · %s" % coin,
                  "Tendencia, momentum, volatilidad y niveles en velas diarias.", rows,
                  ["Zonas calculadas con pivotes; no incluye volumen ni detección de patrones. No es asesoramiento financiero."])


# ---------- 9. Multi-timeframe ----------------------------------------------
_TF_LABELS = (("1M", "Mensual"), ("1w", "Semanal"), ("1d", "Diario"), ("4h", "4 horas"), ("15m", "15 minutos"))


def multi_timeframe(p, coin="bitcoin", progress=None):
    rows, signs, notes = [], [], []
    for i, (tf, label) in enumerate(_TF_LABELS):
        _step(progress, i, len(_TF_LABELS), "%s · %s" % (coin, label))
        try:
            # Mensual: solo ~12 velas en 365 d, así que EMA 3/6 y sin MACD.
            b = bias(p.closes(coin, tf), 3, 6, False) if tf == "1M" else bias(p.closes(coin, tf))
        except ProviderError as e:
            notes.append("%s sin datos: %s" % (label, e))
            b = None
        if b is None:
            rows.append(Row(label, "Sin datos suficientes", 0, "Sin datos", "mid"))
            continue
        signs.append(b)
        rule = "EMA 3/6" if tf == "1M" else "EMA 20/50 y MACD"
        rows.append({1: Row(label, "Alcista según %s" % rule, 75, "Alcista", "up"),
                     0: Row(label, "Señales mixtas (%s)" % rule, 50, "Neutral", "mid"),
                     -1: Row(label, "Bajista según %s" % rule, 25, "Bajista", "down")}[b])
    if signs:
        pos, neg = signs.count(1), signs.count(-1)
        top = max(pos, neg)
        tone = "up" if pos > neg else "down" if neg > pos else "mid"
        side = "alcista" if pos > neg else "bajista" if neg > pos else "sin sesgo"
        rows.append(Row("Confluencia", "Marcos alineados (%s)" % side, top / len(signs) * 100,
                        "%d de %d" % (top, len(signs)), tone))
    notes.append("Mensual (EMA 3/6) y semanal salen de ≤365 días de histórico (plan gratuito); 15 min se remuestrea desde 5 min.")
    return Result("mtf", "Multi-timeframe · %s" % coin,
                  "Sesgo por marco temporal y número de marcos que coinciden.", rows, notes)


# ---------- 10. Explicar indicadores ----------------------------------------
LESSONS = (
    "RSI: mide la fuerza de las subidas frente a las bajadas (0-100). Sobre 70 suele indicar sobrecompra y bajo 30 sobreventa; "
    "en tendencias fuertes puede quedarse ahí mucho tiempo.",
    "MACD: diferencia entre dos medias (12 y 26). Un cruce de la línea sobre su señal sugiere ganar impulso; "
    "el histograma muestra esa distancia.",
    "Soporte y resistencia: busca precios donde el mercado giró varias veces (pivotes). Cuantos más toques, más relevante el nivel.",
    "Patrones de gráfico: figuras que repiten comportamiento (dobles techos, triángulos…). Su detección automática "
    "no está incluida; se explican, no se detectan.",
)


def explain_indicators(p, coin=None, progress=None):
    notes = []
    u = _universe_closes(p, progress, notes)
    n = len(u)
    rs = [(c.symbol, rsi(cl)) for c, cl in u.values()]
    rs = [(s, v) for s, v in rs if v is not None]
    ob = sum(1 for _, v in rs if v >= 70)
    os_ = sum(1 for _, v in rs if v <= 30)
    bull = sum(1 for _, cl in u.values() if (last(macd(cl)[2]) or 0) > 0)
    rows = [
        Row("RSI", "%d en sobrecompra · %d en sobreventa de %d" % (ob, os_, n), ob / max(n, 1) * 100,
            "Pocas" if ob <= n * 0.2 else "Muchas", "mid" if ob <= n * 0.2 else "down"),
        Row("MACD", "%d de %d con histograma positivo" % (bull, n), bull / max(n, 1) * 100,
            "Mayoría alcista" if bull > n / 2 else "Mayoría bajista", "up" if bull > n / 2 else "down"),
    ]
    b = _breadth(u, 50)
    if b is not None:
        rows.append(_breadth_row("Estructura (sobre EMA 50)", b))
    return Result("learn", "Explicar indicadores",
                  "Cada indicador con una explicación breve y su lectura actual en el universo.",
                  rows, list(LESSONS) + notes)


# ---------- registro ---------------------------------------------------------
ANALYSES = (
    Analysis("compare", "Comparativas", "Comparar BTC y ETH", "Setups técnicos", False, compare_btc_eth,
             ("Compare BTC and ETH technical setups",)),
    Analysis("divergence", "", "Altcoins que divergen de BTC", "Correlación móvil 30 d", False, divergences,
             ("Which altcoins are diverging from BTC?",)),
    Analysis("uncorrelated", "", "Oportunidades no correlacionadas", "Baja correlación + técnica", False, uncorrelated,
             ("Show me non-correlated crypto opportunities",)),
    Analysis("diversify", "", "Mejor diversificación técnica", "Pesos sugeridos", False, diversification,
             ("Best diversification based on technicals",)),
    Analysis("rotation", "", "Rotación sectorial", "Fuerza relativa vs BTC, 7 d", False, sector_rotation,
             ("Analyze sector rotation in crypto",)),
    Analysis("sentiment", "Mercado", "Sentimiento y régimen", "Risk-on / risk-off", False, sentiment_regime,
             ("What's the overall crypto market sentiment?", "Are we in risk-on or risk-off mode?",
              "Bull market vs bear market indicators", "Are we in accumulation or distribution?",
              "What's the major trend in crypto right now?", "Is this a good time to be in crypto?")),
    Analysis("levels", "", "Amplitud y niveles clave", "Estructura de mercado", False, breadth_levels,
             ("Technical breadth analysis of crypto market", "Major market support and resistance levels",
              "Key levels that would change the trend", "Show me the market structure on higher timeframes",
              "Explain the current market structure")),
    Analysis("asset", "Activo", "Informe profundo por activo", "BTC, ETH, SOL, NEAR, DOT", True, asset_report,
             ("Do a complete Wall Street analyst report on BTC", "Analyze ETH like a hedge fund would",
              "Give me all technical indicators, patterns, and signals for SOL",
              "Professional trading desk analysis on NEAR PROTOCOL", "Institutional entry and exit points for DOT")),
    Analysis("mtf", "", "Multi-timeframe y confluencia", "De mensual a 15 min", True, multi_timeframe,
             ("Show me multi-timeframe analysis on BTC", "Where do all timeframes align for ETH?",
              "Confluence zones across all timeframes", "Best entries confirmed by multiple timeframes",
              "Top-down analysis from monthly to 4h")),
    Analysis("learn", "Aprender", "Explicar indicadores", "RSI, MACD, patrones, niveles", False, explain_indicators,
             ("Explain what the RSI is telling us about TOP 20 COINS", "Teach me how to read MACD signals",
              "What does this chart pattern mean?", "How do I identify support and resistance?",
              "Explain the current market structure")),
)


def by_id(analysis_id):
    for a in ANALYSES:
        if a.id == analysis_id:
            return a
    raise KeyError(analysis_id)
