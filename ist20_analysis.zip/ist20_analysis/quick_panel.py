"""Panel Tkinter «Análisis rápido». La red corre en un hilo; la interfaz solo se toca desde el hilo principal."""
import queue
import threading
import tkinter as tk
from tkinter import ttk

from .analyses import ANALYSES
from .config import ASSET_CHOICES

BAR = {"up": "#1F4E8C", "mid": "#6B7280", "down": "#B45309"}
TXT = {"up": "#1F4E8C", "mid": "#4B5563", "down": "#92400E"}


class QuickAnalysisPanel(ttk.Frame):
    def __init__(self, master, provider, **kw):
        super().__init__(master, **kw)
        self._provider = provider
        self._q = queue.Queue()
        self._job = 0
        self._current = ANALYSES[0]
        self._buttons = {}
        self._build()
        self._poll()
        self.select(self._current.id)

    # ---- construcción -----------------------------------------------------
    def _build(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        nav = ttk.Frame(self, padding=8)
        nav.grid(row=0, column=0, sticky="ns")
        for a in ANALYSES:
            if a.group:
                ttk.Label(nav, text=a.group.upper(), foreground="#4B5563").pack(anchor="w", pady=(10, 2))
            b = ttk.Button(nav, text="%s\n%s" % (a.button, a.sub), width=32,
                           command=lambda i=a.id: self.select(i))
            b.pack(fill="x", pady=2)
            self._buttons[a.id] = b

        main = ttk.Frame(self, padding=12)
        main.grid(row=0, column=1, sticky="nsew")
        main.columnconfigure(0, weight=1)
        self._title = ttk.Label(main, font=("Segoe UI", 16, "bold"))
        self._title.grid(row=0, column=0, sticky="w")
        self._coin = tk.StringVar(value=ASSET_CHOICES[0])
        self._combo = ttk.Combobox(main, textvariable=self._coin, values=ASSET_CHOICES, width=14)
        self._combo.grid(row=0, column=1, sticky="e")
        self._combo.bind("<<ComboboxSelected>>", lambda e: self.select(self._current.id))
        self._combo.bind("<Return>", lambda e: self.select(self._current.id))
        self._how = ttk.Label(main, wraplength=640, foreground="#4B5563")
        self._how.grid(row=1, column=0, columnspan=2, sticky="w", pady=(2, 8))
        self._status = ttk.Label(main, foreground="#4B5563")
        self._status.grid(row=2, column=0, columnspan=2, sticky="w")
        self._rows = ttk.Frame(main)
        self._rows.grid(row=3, column=0, columnspan=2, sticky="nsew")
        self._rows.columnconfigure(0, weight=1)
        self._notes = ttk.Label(main, wraplength=640, foreground="#4B5563", justify="left")
        self._notes.grid(row=4, column=0, columnspan=2, sticky="w", pady=(10, 0))
        self._asks = ttk.Label(main, wraplength=640, justify="left")
        self._asks.grid(row=5, column=0, columnspan=2, sticky="w", pady=(10, 0))

    # ---- acciones ---------------------------------------------------------
    def select(self, analysis_id):
        self._current = next(a for a in ANALYSES if a.id == analysis_id)
        a = self._current
        self._job += 1
        job, coin = self._job, self._coin.get().strip().lower()
        self._title.config(text=a.button)
        self._how.config(text="")
        self._notes.config(text="")
        self._asks.config(text="Preguntas que responde:\n• " + "\n• ".join(a.asks))
        (self._combo.grid if a.needs_coin else self._combo.grid_remove)()
        for w in self._rows.winfo_children():
            w.destroy()
        self._status.config(text="Calculando…")

        def work():
            try:
                res = a.fn(self._provider, coin, lambda i, n, m: self._q.put((job, "prog", "%s (%d/%d)" % (m, i + 1, n))))
                self._q.put((job, "ok", res))
            except Exception as e:  # el hilo nunca debe morir en silencio
                self._q.put((job, "err", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _poll(self):
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:  # la aplicación ya se cerró
            return
        try:
            while True:
                job, kind, payload = self._q.get_nowait()
                if job != self._job:
                    continue  # resultado de una selección anterior
                if kind == "prog":
                    self._status.config(text=payload)
                elif kind == "err":
                    self._status.config(text="No se pudo calcular: %s" % payload)
                else:
                    self._render(payload)
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _render(self, res):
        self._status.config(text="")
        self._title.config(text=res.title)
        self._how.config(text=res.how)
        self._notes.config(text="\n".join("• " + n for n in res.notes))
        for r in res.rows:
            f = ttk.Frame(self._rows, padding=(0, 4))
            f.pack(fill="x")
            f.columnconfigure(0, weight=1)
            ttk.Label(f, text=r.label, font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w")
            ttk.Label(f, text=r.val, foreground="#4B5563").grid(row=1, column=0, sticky="w")
            c = tk.Canvas(f, width=200, height=10, highlightthickness=0, bg="#E5E7EB")
            c.create_rectangle(0, 0, 200 * r.pct / 100.0, 10, fill=BAR[r.tone], width=0)
            c.grid(row=0, column=1, rowspan=2, padx=12)
            tk.Label(f, text=r.tag, fg=TXT[r.tone], font=("Segoe UI", 9, "bold"), width=22,
                     anchor="e").grid(row=0, column=2, rowspan=2)
