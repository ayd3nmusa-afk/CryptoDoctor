"""Ajustes del módulo. Todo lo que quieras cambiar sin tocar la lógica está aquí."""

BASE_URL = "https://api.coingecko.com/api/v3"  # solo HTTPS
REQUEST_TIMEOUT_S = 15
MIN_REQUEST_INTERVAL_S = 2.5  # separación entre peticiones al plan gratuito
CACHE_TTL_S = {"universe": 600, "15m": 300, "4h": 900, "1d": 1800}

UNIVERSE_SIZE = 20
EXTRA_COINS = ("bittensor",)  # TAO se añade siempre al universo
MIN_VOLUME_USD = 0  # 0 = sin filtro de volumen en "no correlacionadas"

STABLECOIN_IDS = frozenset({
    "tether", "usd-coin", "dai", "first-digital-usd", "ethena-usde", "usds",
    "usd1-wlfi", "paypal-usd", "true-usd", "binance-usd", "usdd", "frax",
    "global-dollar", "usdt0",
})
STABLECOIN_SYMBOLS = frozenset({
    "USDT", "USDC", "DAI", "FDUSD", "USDE", "USDS", "USD1", "PYUSD", "TUSD",
    "BUSD", "USDD", "FRAX", "USDG",
})
# Envolturas y derivados líquidos: distorsionan correlaciones con BTC/ETH.
WRAPPED_IDS = frozenset({
    "staked-ether", "wrapped-bitcoin", "weth", "wrapped-steth", "wrapped-eeth",
    "coinbase-wrapped-btc", "binance-staked-eth",
})

ASSET_CHOICES = ("bitcoin", "ethereum", "solana", "near", "polkadot", "bittensor")

# Sectores para la rotación. Edítalo libremente; lo no listado va a "Otros".
SECTORS = {
    "bitcoin": "Reserva de valor",
    "ethereum": "Capa 1", "solana": "Capa 1", "cardano": "Capa 1",
    "avalanche-2": "Capa 1", "near": "Capa 1", "polkadot": "Capa 1",
    "sui": "Capa 1", "tron": "Capa 1", "the-open-network": "Capa 1",
    "chainlink": "Infraestructura",
    "bittensor": "IA",
    "uniswap": "DeFi", "aave": "DeFi",
    "dogecoin": "Memecoins", "shiba-inu": "Memecoins",
    "ripple": "Pagos", "stellar": "Pagos", "litecoin": "Pagos",
    "bitcoin-cash": "Pagos",
    "binancecoin": "Exchange",
}
