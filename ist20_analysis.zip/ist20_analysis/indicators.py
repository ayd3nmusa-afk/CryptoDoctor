"""Indicadores técnicos en Python puro. Las series devuelven None donde aún no hay dato."""
import math


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def ema(values, n):
    out = [None] * len(values)
    if len(values) < n:
        return out
    k = 2.0 / (n + 1)
    prev = sum(values[:n]) / n
    out[n - 1] = prev
    for i in range(n, len(values)):
        prev = values[i] * k + prev * (1 - k)
        out[i] = prev
    return out


def last(series):
    for v in reversed(series):
        if v is not None:
            return v
    return None


def rsi(values, n=14):
    """RSI de Wilder; devuelve el último valor o None."""
    if len(values) <= n:
        return None
    gains = losses = 0.0
    for i in range(1, n + 1):
        d = values[i] - values[i - 1]
        gains += max(d, 0)
        losses += max(-d, 0)
    avg_g, avg_l = gains / n, losses / n
    for i in range(n + 1, len(values)):
        d = values[i] - values[i - 1]
        avg_g = (avg_g * (n - 1) + max(d, 0)) / n
        avg_l = (avg_l * (n - 1) + max(-d, 0)) / n
    if avg_l == 0:
        return 100.0
    return 100.0 - 100.0 / (1 + avg_g / avg_l)


def macd(values, fast=12, slow=26, signal=9):
    """Devuelve (línea, señal, histograma), alineadas con la entrada."""
    n = len(values)
    ef, es = ema(values, fast), ema(values, slow)
    line = [a - b if a is not None and b is not None else None for a, b in zip(ef, es)]
    start = next((i for i, v in enumerate(line) if v is not None), None)
    sig = [None] * n
    if start is not None:
        seg = ema(line[start:], signal)
        sig[start:] = seg
    hist = [a - b if a is not None and b is not None else None for a, b in zip(line, sig)]
    return line, sig, hist


def returns(values):
    return [values[i] / values[i - 1] - 1 for i in range(1, len(values)) if values[i - 1]]


def pearson(a, b, n=None, min_n=10):
    m = min(len(a), len(b)) if n is None else min(n, len(a), len(b))
    if m < min_n:
        return None
    a, b = a[-m:], b[-m:]
    ma, mb = sum(a) / m, sum(b) / m
    cov = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    va = sum((x - ma) ** 2 for x in a)
    vb = sum((y - mb) ** 2 for y in b)
    if va == 0 or vb == 0:
        return None
    return cov / math.sqrt(va * vb)


def stdev(values):
    if len(values) < 2:
        return None
    m = sum(values) / len(values)
    return math.sqrt(sum((v - m) ** 2 for v in values) / (len(values) - 1))


def slope(values, n=30):
    """Pendiente relativa por barra (regresión lineal sobre las últimas n)."""
    v = values[-n:]
    m = len(v)
    if m < 5:
        return None
    xs = range(m)
    mx, my = (m - 1) / 2.0, sum(v) / m
    den = sum((x - mx) ** 2 for x in xs)
    if den == 0 or my == 0:
        return None
    return sum((x - mx) * (y - my) for x, y in zip(xs, v)) / den / my


def pivots(values, window=5):
    highs, lows = [], []
    for i in range(window, len(values) - window):
        seg = values[i - window:i + window + 1]
        if values[i] == max(seg):
            highs.append(values[i])
        if values[i] == min(seg):
            lows.append(values[i])
    return lows, highs


def nearest_levels(values, window=5, lookback=180):
    """(soporte, resistencia) más cercanos al último precio, desde pivotes."""
    v = values[-lookback:]
    price = v[-1]
    lows, highs = pivots(v, window)
    below = [x for x in lows if x < price]
    above = [x for x in highs if x > price]
    return (max(below) if below else None), (min(above) if above else None)


def bias(values, fast=20, slow=50, use_macd=True):
    """+1 / 0 / -1 según precio, dos EMA y (opcional) histograma MACD."""
    ef, es = last(ema(values, fast)), last(ema(values, slow))
    if ef is None or es is None:
        return None
    h = last(macd(values)[2]) if use_macd else 0
    if h is None:
        return None
    p = values[-1]
    if p > ef > es and (h > 0 or not use_macd):
        return 1
    if p < ef < es and (h < 0 or not use_macd):
        return -1
    return 0
